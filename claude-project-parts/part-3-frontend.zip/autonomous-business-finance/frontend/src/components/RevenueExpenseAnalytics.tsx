import React from 'react';
import { BarChart3, PieChart, Sparkles, AlertCircle } from 'lucide-react';
import type { FinancialMetrics } from '../types/finance';

interface Props {
  metrics: FinancialMetrics | null;
  onSimulateAnomaly: () => void;
  isSimulating: boolean;
}

export const RevenueExpenseAnalytics: React.FC<Props> = ({ metrics, onSimulateAnomaly, isSimulating }) => {
  const monthlyData = [
    { month: 'May', revenue: 195000, expenses: 165000 },
    { month: 'Jun', revenue: 210000, expenses: 178000 },
    { month: 'Jul', revenue: 228000, expenses: 192000 },
    { month: 'Aug', revenue: 235000, expenses: 205000 },
    { month: 'Sep', revenue: 242000, expenses: 218000 },
    { month: 'Oct (Current)', revenue: metrics?.totalRevenue || 245000, expenses: metrics?.totalExpenses || 239700 },
  ];

  const maxAmount = Math.max(...monthlyData.map((d) => Math.max(d.revenue, d.expenses))) * 1.15;

  const categoryBreakdown = [
    { category: 'Payroll & Engineering', percentage: 45, color: 'var(--accent)', amount: '$108,000' },
    { category: 'Cloud Infrastructure (AWS/GCP)', percentage: 22, color: '#FFA07A', amount: '$52,850' },
    { category: 'Sales & Inbound Marketing', percentage: 16, color: '#F59E0B', amount: '$38,400' },
    { category: 'SaaS Software Subscriptions', percentage: 10, color: '#38BDF8', amount: '$24,000' },
    { category: 'G&A & Operational', percentage: 7, color: '#64748B', amount: '$16,450' },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Monthly Bar Trend */}
      <div
        className="lg:col-span-2 rounded-2xl p-6 shadow-sm border"
        style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
      >
        <div
          className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b gap-3"
          style={{ borderColor: 'var(--border)' }}
        >
          <div>
            <div className="flex items-center gap-2 font-semibold text-lg" style={{ color: 'var(--text-primary)' }}>
              <BarChart3 className="w-5 h-5" style={{ color: 'var(--accent)' }} />
              <span>Revenue vs. Operational Spend Velocity</span>
            </div>
            <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
              Trailing 6-month trajectory and current monthly pacing
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm" style={{ backgroundColor: 'var(--accent)' }} />
              <span style={{ color: 'var(--text-secondary)' }}>Revenue</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-rose-500/80" />
              <span style={{ color: 'var(--text-secondary)' }}>Expenses</span>
            </div>
          </div>
        </div>

        {/* Visual Bar Chart */}
        <div className="mt-8 space-y-4">
          <div
            className="grid grid-cols-6 gap-2 sm:gap-4 h-48 items-end pt-4 border-b"
            style={{ borderColor: 'var(--border)' }}
          >
            {monthlyData.map((d, index) => {
              const revHeight = (d.revenue / maxAmount) * 100;
              const expHeight = (d.expenses / maxAmount) * 100;

              return (
                <div key={index} className="flex flex-col items-center h-full justify-end group">
                  <div className="w-full flex items-end justify-center gap-1 h-full">
                    {/* Revenue Bar */}
                    <div
                      style={{ height: `${revHeight}%`, backgroundColor: 'var(--accent)' }}
                      className="w-1/2 rounded-t-sm transition-all duration-500 opacity-90 group-hover:opacity-100"
                      title={`Revenue: $${d.revenue.toLocaleString()}`}
                    />
                    {/* Expense Bar */}
                    <div
                      style={{ height: `${expHeight}%` }}
                      className="w-1/2 bg-rose-500/70 rounded-t-sm transition-all duration-500 group-hover:bg-rose-500/90"
                      title={`Expenses: $${d.expenses.toLocaleString()}`}
                    />
                  </div>
                  <span
                    className="text-[10px] font-mono mt-2 truncate w-full text-center"
                    style={{ color: 'var(--text-muted)' }}
                  >
                    {d.month}
                  </span>
                </div>
              );
            })}
          </div>

          <div
            className="flex flex-col sm:flex-row sm:items-center justify-between text-xs pt-2 gap-2"
            style={{ color: 'var(--text-muted)' }}
          >
            <span>
              Operating Margin:{' '}
              <strong className="font-mono" style={{ color: 'var(--accent)' }}>
                +{metrics?.netMarginPercent || 2.2}%
              </strong>
            </span>
            <div className="flex items-center gap-1 text-[11px]">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>Autonomous categorization active across all channels</span>
            </div>
          </div>
        </div>
      </div>

      {/* Expense Allocation & Real-Time Demo Anomaly Trigger */}
      <div
        className="rounded-2xl p-6 shadow-sm border flex flex-col justify-between"
        style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
      >
        <div>
          <div
            className="flex items-center gap-2 font-semibold text-lg pb-4 border-b"
            style={{ color: 'var(--text-primary)', borderColor: 'var(--border)' }}
          >
            <PieChart className="w-5 h-5" style={{ color: 'var(--accent)' }} />
            <span>Spend Category Allocation</span>
          </div>

          <div className="mt-4 space-y-3">
            {categoryBreakdown.map((c) => (
              <div key={c.category} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium" style={{ color: 'var(--text-secondary)' }}>
                    {c.category}
                  </span>
                  <span className="font-mono" style={{ color: 'var(--text-muted)' }}>
                    {c.amount} ({c.percentage}%)
                  </span>
                </div>
                <div
                  className="w-full rounded-full h-1.5 overflow-hidden"
                  style={{ backgroundColor: 'var(--bg-secondary)' }}
                >
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${c.percentage}%`, backgroundColor: c.color }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Real-Time Anomaly Simulation Trigger Box */}
        <div
          className="mt-6 p-4 rounded-xl border"
          style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border)' }}
        >
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
            <Sparkles className="w-4 h-4" />
            <span>Autonomous Engine Testing Harness</span>
          </div>
          <p className="text-[11px] mt-1 leading-relaxed" style={{ color: 'var(--text-muted)' }}>
            Ingest a sudden high-value anomalous charge to test real-time detection by the Expense Management Agent.
          </p>
          <button
            onClick={onSimulateAnomaly}
            disabled={isSimulating}
            className="mt-3 w-full py-2 px-3 rounded-lg border text-amber-400 font-medium text-xs flex items-center justify-center gap-2 transition-colors disabled:opacity-50 cursor-pointer hover:bg-amber-500/20 border-amber-500/30 bg-amber-500/10"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isSimulating ? 'Simulating Anomaly...' : 'Simulate $18,400 Compute Spike'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
