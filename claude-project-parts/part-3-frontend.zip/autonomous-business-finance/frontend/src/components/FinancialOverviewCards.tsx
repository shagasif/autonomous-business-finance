import React from 'react';
import { DollarSign, TrendingUp, TrendingDown, Clock, ShieldAlert, FileText } from 'lucide-react';
import type { FinancialMetrics } from '../types/finance';

interface Props {
  metrics: FinancialMetrics | null;
  currency?: string;
  onSelectTab: (tab: 'overview' | 'agents' | 'cashflow' | 'budgets' | 'invoices' | 'approvals' | 'reports') => void;
}

export const FinancialOverviewCards: React.FC<Props> = ({ metrics, currency = 'USD', onSelectTab }) => {
  if (!metrics) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-pulse">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="h-32 rounded-2xl p-5 border"
            style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
          />
        ))}
      </div>
    );
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const isProfitable = metrics.netIncome >= 0;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Revenue */}
        <div
          className="rounded-2xl p-5 shadow-sm relative overflow-hidden border"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
        >
          <div className="flex items-center justify-between text-xs" style={{ color: 'var(--text-muted)' }}>
            <span>Total Revenue</span>
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: 'var(--success-muted)', color: 'var(--success)' }}
            >
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-bold tracking-tight" style={{ color: 'var(--text-primary)' }}>
            {formatCurrency(metrics.totalRevenue)}
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-xs" style={{ color: 'var(--success)' }}>
            <span className="font-semibold">+7.4%</span>
            <span style={{ color: 'var(--text-muted)' }}>vs prior period</span>
          </div>
        </div>

        {/* Total Expenses */}
        <div
          className="rounded-2xl p-5 shadow-sm relative overflow-hidden border"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
        >
          <div className="flex items-center justify-between text-xs" style={{ color: 'var(--text-muted)' }}>
            <span>Operational Expenses</span>
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: 'var(--danger-muted)', color: 'var(--danger)' }}
            >
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-bold tracking-tight" style={{ color: 'var(--text-primary)' }}>
            {formatCurrency(metrics.totalExpenses)}
          </div>
          <div className="mt-2 flex items-center justify-between text-xs" style={{ color: 'var(--text-muted)' }}>
            <span>
              Burn Rate:{' '}
              <strong style={{ color: 'var(--text-secondary)' }}>
                {formatCurrency(metrics.monthlyBurnRate)}/mo
              </strong>
            </span>
          </div>
        </div>

        {/* Net Income & Margin */}
        <div
          className="rounded-2xl p-5 shadow-sm relative overflow-hidden border"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
        >
          <div className="flex items-center justify-between text-xs" style={{ color: 'var(--text-muted)' }}>
            <span>Net Operating Income</span>
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{
                backgroundColor: isProfitable ? 'var(--success-muted)' : 'var(--danger-muted)',
                color: isProfitable ? 'var(--success)' : 'var(--danger)',
              }}
            >
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div
            className="mt-2 text-2xl font-bold tracking-tight"
            style={{ color: isProfitable ? 'var(--success)' : 'var(--danger)' }}
          >
            {formatCurrency(metrics.netIncome)}
          </div>
          <div className="mt-2 flex items-center gap-2 text-xs">
            <span
              className="px-2 py-0.5 rounded font-mono font-medium"
              style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-secondary)' }}
            >
              Margin: {metrics.netMarginPercent}%
            </span>
          </div>
        </div>

        {/* Liquid Reserves & Runway */}
        <div
          className="rounded-2xl p-5 shadow-sm relative overflow-hidden border"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
        >
          <div className="flex items-center justify-between text-xs" style={{ color: 'var(--text-muted)' }}>
            <span>Liquid Cash &amp; Reserves</span>
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: 'var(--accent-muted)', color: 'var(--accent)' }}
            >
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-bold tracking-tight" style={{ color: 'var(--text-primary)' }}>
            {formatCurrency(metrics.cashBalance)}
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-xs" style={{ color: 'var(--accent)' }}>
            <span className="font-semibold font-mono">{metrics.runwayMonths} Months</span>
            <span style={{ color: 'var(--text-muted)' }}>estimated runway</span>
          </div>
        </div>
      </div>

      {/* Secondary Quick Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
        <div
          onClick={() => onSelectTab('invoices')}
          className="p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors hover:border-[var(--border-hover)]"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
        >
          <div className="flex items-center gap-2" style={{ color: 'var(--text-secondary)' }}>
            <FileText className="w-4 h-4" style={{ color: 'var(--success)' }} />
            <span>Accounts Receivable</span>
          </div>
          <span className="font-mono font-semibold" style={{ color: 'var(--text-primary)' }}>
            {formatCurrency(metrics.accountsReceivableTotal)}
          </span>
        </div>

        <div
          onClick={() => onSelectTab('invoices')}
          className="p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors hover:border-[var(--border-hover)]"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
        >
          <div className="flex items-center gap-2" style={{ color: 'var(--text-secondary)' }}>
            <FileText className="w-4 h-4 text-amber-400" />
            <span>Accounts Payable</span>
          </div>
          <span className="font-mono font-semibold" style={{ color: 'var(--text-primary)' }}>
            {formatCurrency(metrics.accountsPayableTotal)}
          </span>
        </div>

        <div
          onClick={() => onSelectTab('invoices')}
          className="p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors hover:border-[var(--border-hover)]"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
        >
          <div className="flex items-center gap-2" style={{ color: 'var(--text-secondary)' }}>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>Overdue Invoices</span>
          </div>
          <span className="font-mono font-semibold text-rose-400">
            {metrics.overdueInvoicesCount} accounts
          </span>
        </div>

        <div
          onClick={() => onSelectTab('approvals')}
          className="p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors hover:border-[var(--border-hover)]"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border)' }}
        >
          <div className="flex items-center gap-2" style={{ color: 'var(--text-secondary)' }}>
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>Active Anomalies</span>
          </div>
          <span className="font-mono font-semibold text-amber-400">
            {metrics.activeAnomaliesCount} flagged
          </span>
        </div>
      </div>
    </div>
  );
};
